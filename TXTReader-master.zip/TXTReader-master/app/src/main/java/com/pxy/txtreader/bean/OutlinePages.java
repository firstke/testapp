package com.pxy.txtreader.bean;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by pxy on 2016/3/31.
 */
public class OutlinePages {
    public Outline outline;
    public String text

            ;
    public List<Long> Indexs = new ArrayList<>();
}
